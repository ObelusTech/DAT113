import java.io.IOException;
public class mainRunner {

    public static void main(String[] args) throws IOException {

        new Model();
        new Controller();

    }

}
