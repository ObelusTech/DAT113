public class mainRunner {

    public static void main(String[] args) {

        GUI.toMainRunner();

    }

}
