package snake;

public class MainRunner {

    public static void main(String[] args) {

        // .....

    }

}
