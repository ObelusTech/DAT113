package TT;


import javax.swing.*;
import java.util.Random;

public class Assignment03Runner {

    public static void main(String[] args) {

        //Assignment03Funksjoner.ValidNumbers();
        Assignment03GUI Interface = new Assignment03GUI();

    }
}
