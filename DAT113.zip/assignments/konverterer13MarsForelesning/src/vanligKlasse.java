public class vanligKlasse {
    public String entekst = "";
}

